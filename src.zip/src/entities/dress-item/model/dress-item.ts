export type DressItem = {
  id: number | null,
  name: string
}
