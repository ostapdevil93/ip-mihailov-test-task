import MainPage from './ui/main-page.vue';

export { MainPage };