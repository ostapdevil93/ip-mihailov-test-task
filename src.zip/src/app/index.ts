import App from './app.vue';

export { App };
