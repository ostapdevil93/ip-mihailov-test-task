<script setup lang="ts">

</script>

<template>
  <div id="ip-mihailov-test-task">
    <router-view />
  </div>
</template>

<style lang="scss">

</style>
